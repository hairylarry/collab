<?php
session_start();

$username = $_POST["username"];
$password = $_POST["password"];
$fname = "usernames/".$username.".txt";

$myfile = fopen($fname, "r") or die("Unable to open file!");
$userid = fgets($myfile);
$email = fgets($myfile);
$pwtext = rtrim(fgets($myfile));
fclose($myfile);

if($password == $pwtext){
  $_SESSION["userid"] = $userid;
  $_SESSION["username"] = $username;
  $cookie_name = "username";
  $cookie_value = $username;
  setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
  header('Location: http://192.168.1.14/collab/index.php');
}
else{
  echo "Wrong username or password. Please use your back button to try again.";
}


?>
