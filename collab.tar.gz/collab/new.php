<?php

session_start();
include("config.cfg");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

echo "<html>";
echo "<head>";
echo "<title>$title - Create Account</title>";

echo "</head>";
echo "<body>";

include("header.inc");

?>

<table><tr><td valign=top>
<?php include("posts.inc"); ?>
</td>
<td valign=top>
<?php include("new.inc"); ?>
</td></tr></table>

<?php include("footer.inc"); ?>

</body>
</html>

