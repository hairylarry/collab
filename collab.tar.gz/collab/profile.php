<?php

session_start();
include("config.cfg");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

echo "<html>";
echo "<head>";
echo "<title>$title - Profile</title>";

$profile = $_POST["profile"];
$profilename = $_POST["profilename"];

//post profile
if($profile == "profile"){
  $tagline = $_POST["tagline"];
  $content = $_POST["content"];
  $fname = $_POST["fname"];

  if(strlen($userid) == 0){
    $cookie_name = "username";
    if(!isset($_COOKIE[$cookie_name])) {
      echo "Oh oh, you're not logged in. Please copy your text, save it, and then <a href='login.php'>Log In</a>.";
      echo "<table width=600 border=1><tr><td>";
      echo "<blockquote><p>";
      echo $content;
      echo "</blockquote>";
      echo "</td></tr?</table>";
      break;
    } else {
      $username = $_COOKIE[$cookie_name];
      $file = fopen("usernames/".$username.".txt", "r") or die("Unable to open file! ".$username);
      $userid = rtrim(fgets($file));
      fclose($file);
      $_SESSION["userid"] = $userid;
      $_SESSION["username"] = $username;
    }
  }

  mkdir($userid, 0755);

  $file = fopen($fname,"w") or die("Unable to open file!");
  fwrite($file,":TAGLINE:".htmlspecialchars($tagline)."\n".htmlspecialchars($content));
  fclose($file);
}


echo "</head>";
echo "<body>";

include("header.inc");

?>

<table><tr><td valign=top>
<?php include("posts.inc"); ?>
</td>
<td valign=top>
<?php include("profile.inc"); ?>
</td></tr></table>
<?php include("footer.inc"); ?>

</body>
</html>

