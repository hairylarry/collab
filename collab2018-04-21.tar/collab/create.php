<?php
session_start();
include("config.txt");
//$userid = rtrim($_SESSION["userid"]);
//$username = $_SESSION["username"];
$createuser = $_POST["createuser"];
$ccby = $_POST["ccby"];

//Create User
if($createuser == "createuser"){
  $newusername = $_POST["username"];
  $email = $_POST["email"];
  $confirmflag = 1;
  if(file_exists("usernames/".$newusername.".txt")){
    $message .= "Username already exists. Please select another username.<p>";
    $confirmflag = 0;
  }
  if(file_exists("emails/".$email.".txt")){
    $message .= "This email address already exists. Please check that you did not mistype your email. If your email is correct you probably already have an account. If you remember your user name and password you can log in. If you don't select Log In and then Lost Password to recover your account information.<p>";
    $confirmflag = 0;
  }
  if($ccby <> "on"){
    $message .= "Please click the checkbox to agree to CC-BY licensing. This gives us and others permission to repost your work with correct writer attribution.<p>";
    $confirmflag = 0;
  }

  if($confirmflag == 1){
    $password = substr(crypt($_POST["password"], '$2a$07$MySaltIsPepperCayenneE$'),29);
    $confirmcode = md5(uniqid(rand()));
    //get new userid
    $dir = 'userids';
    $files = scandir($dir, 1);
    $newuserid = 0;
    foreach($files as $n){
      $seqnum = substr($n,0,6);
      if($seqnum > $newuserid){
        $newuserid = $seqnum;
      }
    }

    $newuserid = $newuserid+1;
    $newuserid = str_pad($newuserid,6,"0",STR_PAD_LEFT);
    $fname = "userids/".$newuserid.".txt";
    $file = fopen($fname, 'w') or die('Cannot open new userid file:  '.$newuserid);
    fclose($file);

    $fname = "pending/".$confirmcode.".txt";
    $file = fopen($fname, 'w') or die('Cannot open new userid file:  '.$newuserid);
    fwrite($file, $newuserid."\n");
    fwrite($file, $email."\n");
    fwrite($file, $password."\n");
    fwrite($file, $newusername."\n");
    fclose($file);

    $msg = "Thanks for joining Collab. Click this link to confirm your email address and complete the setup of your account.\n\n".$wwwpath."/mconf.php?cc=".$confirmcode."\n\nThere's a Help screen that explains a few things about how Collab works. The main thing is to keep writing and have fun. Thanks";
//    mail($email,"Collab Account Confirmation Email",$msg);
    echo $msg;

    $newusername = "";
    $email = "";
  }
}

echo "<html>";
echo "<head>";
echo "<title>$title - Create Account</title>";
include("collab.css");
?>

<script>
function validateForm(uname,pw){
  var alphaExp = /^[0-9a-zA-Z]+$/;
  if(uname.match(alphaExp) && uname.length>0 && pw.length>5){
    return true;
  }else{
    alert("Please use numbers and letters for your username.\nPasswords must be at least 6 characters long.");
    return false;
  }
}
</script>

<?php
echo "</head>";
echo "<body>";
include("header.inc");

echo "<table><tr><td valign=top>";
include("posts.inc");
echo "</td><td valign=top>";
include("create.inc");
echo "</td></tr></table>";
include("footer.inc");
?>

</body>
</html>

