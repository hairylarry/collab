<?php
include("config.txt");
$cc = $_GET['cc'];
$ccfile = "pending/".$cc.".txt";
if(file_exists($ccfile)){
  $file = fopen($ccfile,"r") or die("Unable to open story file!".$fname);
  $userid = rtrim(fgets($file));
  $email = rtrim(fgets($file));
  $password = rtrim(fgets($file));
  $username = rtrim(fgets($file));
  fclose($file);
}

$fname = "userids/".$userid.".txt";
$file = fopen($fname,"w") or die("Unable to open story file!".$fname);
fwrite($file,$username);
fclose($file);

$fname = "usernames/".$username.".txt";
$file = fopen($fname,"w") or die("Unable to open story file!".$fname);
fwrite($file,$userid."\n");
fwrite($file,$email."\n");
fwrite($file,$password."\n");
fwrite($file,$username."\n");
fclose($file);

$fname = "emails/".$email.".txt";
$file = fopen($fname,"w") or die("Unable to open story file!".$fname);
fwrite($file,$username);
fclose($file);

mkdir($userid);
$fname = $userid."/profile.txt";
$file = fopen($fname,"w") or die("Unable to open story file!".$fname);
fclose($file);

header("Location: ".$wwwpath);
?>

