<?php
session_start();
include("config.cfg");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];
$addmore = $_POST["addmore"];
$startstory = $_POST["startstory"];
$edit = $_POST["edit"];
$posttext = $_POST["posttext"];
$posttitle = $_POST["posttitle"];

echo "<html>";
echo "<head>";
echo "<title>$title - Add To A Story</title>";

?>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
	<link href="//fonts.googleapis.com/css?family=Lato:400" rel="stylesheet" type="text/css" />
	<style>
		*, *:before, *:after { -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; }
		body { font-family: "Lato", "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif; font-weight: 400; font-size: 14px; line-height: 18px; padding: 0; margin: 0; background: #f5f5f5;}
		.wrap { max-width: 600px; margin: 20px auto; background: white; padding: 40px; box-shadow: 0 0 2px #ccc; text-align: left;}
		@media only screen and (max-width: 700px) { .wrap { padding: 15px; } }
		h1 { margin: 40px 0; font-size: 22px; font-weight: bold; color: #666; }
		a { color: #399ae5; text-decoration: none; } a:hover { color: #206ba4; text-decoration: none; }
		.note { padding:  0 5px 25px 0; font-size:80%; color: #666; line-height: 18px; }
		.block { clear: both;  min-height: 50px; border-top: solid 1px #ECE9E9; }
		.block:first-child { border: none; }
		.block .img { width: 50px; height: 50px; display: block; float: left; margin-right: 10px; background: transparent url(<?php echo $icon_url; ?>) no-repeat 0 0; }
		.block .date { margin-top: 4px; font-size: 70%; color: #666; }
		.block a { display: block; padding: 10px 15px; transition: all 0.35s; }
		.block a:hover { text-decoration: none; background: #efefef; }
		
		.jpg, .jpeg, .gif, .png { background-position: -50px 0 !important; } 
		.pdf { background-position: -100px 0 !important; }  
		.txt, .rtf { background-position: -150px 0 !important; }
		.xls, .xlsx { background-position: -200px 0 !important; } 
		.ppt, .pptx { background-position: -250px 0 !important; } 
		.doc, .docx { background-position: -300px 0 !important; }
		.zip, .rar, .tar, .gzip { background-position: -350px 0 !important; }
		.swf { background-position: -400px 0 !important; } 
		.fla { background-position: -450px 0 !important; }
		.mp3 { background-position: -500px 0 !important; }
		.wav { background-position: -550px 0 !important; }
		.mp4 { background-position: -600px 0 !important; }
		.mov, .aiff, .m2v, .avi, .pict, .qif { background-position: -650px 0 !important; }
		.wmv, .avi, .mpg { background-position: -700px 0 !important; }
		.flv, .f2v { background-position: -750px 0 !important; }
		.psd { background-position: -800px 0 !important; }
		.ai { background-position: -850px 0 !important; }
		.html, .xhtml, .dhtml, .php, .asp, .css, .js, .inc { background-position: -900px 0 !important; }
		.dir { background-position: -950px 0 !important; }
		
		.sub { margin-left: 20px; border-left: solid 1px #ECE9E9; display: none; }
		
	</style>

<?php
echo "</head>";
echo "<body>";
include("header.inc");

echo $edit;
?>

<table><tr><td valign=top>
<?php include("posts.inc"); ?>
</td>
<td valign=top>

<?php
include("stories.inc");
echo "<a name='addmore'></a><p><blockquote><p>";
if($edit == "edittitle" || $edit == "editpost"){
?>

  <h4>Edit Post</h4>
  <form action="index.php" method="post">

<?php
  if($edit == "edittitle"){
?>

    Title:<br>
    <input type="text" name="posttitle" size='60' autofocus value="<?=$posttitle;?>">
    <p>
    Enter up to 1000 characters:<br>
    <textarea maxlength=<?=$maxchars ?> rows='20' cols='60' name='content'><?=$posttext;?></textarea>
    <input type='hidden' name='edittitle' value='edittitle'>

<?php
  }else{
?>

    <p>
    Enter up to 1000 characters:<br>
    <textarea autofocus maxlength=<?=$maxchars ?> rows='20' cols='60' name='content'><?=$posttext;?></textarea>
    <input type='hidden' name='editpost' value='editpost'>

  <?php
  }

  echo "<input type='hidden' name='fname' value='".$fname."'>";
//  echo "<input type='hidden' name='post' value='".$post."'>";
  ?>

  <br>
  <input type="submit" value="Submit">
  </form>

<?php
}else{
?>

  <form action="index.php" method="post">
  <p>
  Enter up to 1000 characters:<br>

  <textarea autofocus maxlength=<?=$maxchars ?> rows='20' cols='60' name='content'></textarea>
  <input type='hidden' name='addmore' value='addmore'>

  <?php
  echo "<input type='hidden' name='fname' value='".$fname."'>";
  ?>

  <blockquote>
  <input type="submit" value="Submit">
  </form>

<?php
}
?>

</td></tr></table>

<?php include("footer.inc"); ?>

</body>
</html>
