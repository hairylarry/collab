<?php
session_start();
include("config.cfg");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

echo "<html>";
echo "<head>";
echo "<title>$title</title>";
include("collab.css");
echo "</head>";
echo "<body>";

$addmore = $_POST["addmore"];
$startstory = $_POST["startstory"];
$editpost = $_POST["editpost"];
$edittitle = $_POST["edittitle"];
$loggingin = $_POST["loggingin"];

//Log in
if($loggingin == "loggingin"){

  $username = $_POST["username"];
  $password = $_POST["password"];
  $fname = "usernames/".$username.".txt";

  $myfile = fopen($fname, "r") or die("Unable to open username file!");
  $userid = fgets($myfile);
  $email = fgets($myfile);
  $pwtext = rtrim(fgets($myfile));
  fclose($myfile);

  if($password == $pwtext){
    $_SESSION["userid"] = $userid;
    $_SESSION["username"] = $username;
    $cookie_name = "username";
    $cookie_value = $username;
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
  }
  else{
    echo "Wrong username or password. Please use your back button to try again.";
  }
}

//Start a story - post to files
if($startstory == "startstory"){
  $posttitle = $_POST["posttitle"];
  $content = $_POST["content"];
  $fname = $_POST["fname"];

  if(strlen($userid) == 0){
    echo "Oh oh, you're not logged in. Please copy your text, save it, and then <a href='login.php'>Log In</a>.";
    echo "<table width=600 border=1><tr><td>";
    echo "<blockquote><p>";
    echo $content;
    echo "</blockquote>";
    echo "</td></tr?</table>";
    break;
  }

  mkdir($userid, 0755);

  $file = fopen($fname,"w") or die("Unable to open story file!".$fname);
  fwrite($file,":TITLE:".htmlspecialchars($posttitle)."\n".$content);
  fclose($file);

  $apname = "allposts/".date("Y-m-d").".txt"; 
  $file = fopen($apname,"a") or die("Unable to open allposts file!".$apname);
  fwrite($file,$fname."\n");
  fclose($file);

  $tocname = "toc/".substr($fname,6); 
  $file = fopen($tocname,"w") or die("Unable to open toc file!".$tocname);
  fwrite($file,htmlspecialchars($posttitle)."\n".$userid."\n");
  fclose($file);
}

//Add More to a story - post to files
if($addmore == "addmore"){
  $content = $_POST["content"];
  $pname = $_POST["fname"];

  if(strlen($userid) == 0){
    $cookie_name = "username";
    if(!isset($_COOKIE[$cookie_name])) {
      echo "Oh oh, you're not logged in. Please copy your text, save it, and then <a href='login.php'>Log In</a>.";
      echo "<table width=600 border=1><tr><td>";
      echo "<blockquote><p>";
      echo $content;
      echo "</blockquote>";
      echo "</td></tr?</table>";
      break;
    } else {
      $username = $_COOKIE[$cookie_name];
      $file = fopen("usernames/".$username.".txt", "r") or die("Unable to open file! ".$username);
      $userid = rtrim(fgets($file));
      fclose($file);
      $_SESSION["userid"] = $userid;
      $_SESSION["username"] = $username;
    }
  }

//  mkdir($userid, 0755);

  $fname = $userid."/".date("Y-m-d-H:i:s").".txt"; 
  $file = fopen($fname,"w") or die("Unable to open addmore file! ".$fname);
  fwrite($file,":PARENT:".$pname."\n".htmlspecialchars($content));
  fclose($file);

  $file = fopen($pname,"a") or die("Unable to open parent file! ".$pname);
  fwrite($file,"\n:CHILD:".$fname);
  fclose($file);

  $apname = "allposts/".date("Y-m-d").".txt"; 
  $file = fopen($apname,"a") or die("Unable to open allposts file! ".$apname);
  fwrite($file,$fname."\n");
  fclose($file);
}

//Edit post - post to files
if($editpost == "editpost" || $edittitle == "edittitle"){
  $posttitle = $_POST["posttitle"];
  $content = $_POST["content"];
  $fname = $_POST["fname"];

  if(strlen($userid) == 0){
    $cookie_name = "username";
    if(!isset($_COOKIE[$cookie_name])) {
      echo "Oh oh, you're not logged in. Please copy your text, save it, and then <a href='login.php'>Log In</a>.";
      echo "<table width=600 border=1><tr><td>";
      echo "<blockquote><p>";
      echo $content;
      echo "</blockquote>";
      echo "</td></tr?</table>";
      break;
    } else {
      $username = $_COOKIE[$cookie_name];
      $file = fopen("usernames/".$username.".txt", "r") or die("Unable to open file! ".$username);
      $userid = rtrim(fgets($file));
      fclose($file);
      $_SESSION["userid"] = $userid;
      $_SESSION["username"] = $username;
    }
  }

//  mkdir($userid, 0755);

  if($edittitle == "edittitle"){
    $line1 = ":TITLE:".$posttitle;
  }else{
    $file = fopen($fname, "r") or die("Unable to open fname file to read! ".$fname);
    $line1 = fgets($file);
    fclose($file);
  }

  $file = fopen($fname,"w") or die("Unable to open fname file to write! ".$fname);
  fwrite($file,htmlspecialchars($line1)."\n".htmlspecialchars($content));
  fclose($file);
}

include("header.inc");

echo "<table><tr><td valign=top>";

include("posts.inc");
echo "</td>";
echo "<td valign=top>";
include("stories.inc");
echo "</td></tr></table>";

include("footer.inc");

echo "</body>";
echo "</html>";

?>

