<?php
$confirmcode = md5(uniqid(rand()));
$msg = "Click to confirm\n\nhttp://hairylarry.sdf.org/collab/mconf.php?cc=".$confirmcode."\n\nThanks";
mail("hairylarry@gmail.com","My SDF",$msg);
echo "mail sent";
?> 
