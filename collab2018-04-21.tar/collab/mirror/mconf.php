<?php
$cc = $_GET['cc'];
$fname = "cc.txt";
$file = fopen($fname,"w") or die("Unable to open story file!".$fname);
fwrite($file,$cc);
fclose($file);
?>

