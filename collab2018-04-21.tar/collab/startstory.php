<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];
$addmore = $_POST["addmore"];
$startstory = $_POST["startstory"];
?>

<script type="text/javascript">
function stopRKey(evt) {
  var evt = (evt) ? evt : ((event) ? event : null);
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;}
}
document.onkeypress = stopRKey;
</script>

<?php
echo "<html>";
echo "<head>";
echo "<title>$title - Start Story</title>";
include("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");
?>

<table><tr><td valign=top>
<?php include("posts.inc"); ?>
</td>
<td valign=top>

<table border=1 width=600><tr><td>
<blockquote>
<h2>Start A Story</h2>
</blockquote>
</td></tr></table>
<p>
<table border=1 width=600><tr><td>
<blockquote>
<p>
<form action="index.php" method="post">
Title:<br>
<input type="text" name="posttitle" size='60' autofocus>
<br>
Enter up to 1000 characters:<br>

<?php
echo "<textarea maxlength='$maxchars' rows='18' cols='60' name='content'></textarea>";
$fname = $userid."/".date("Y-m-d-H:i:s").".txt"; 
echo "<input type='hidden' name='fname' value='$fname'>";
?>

<input type='hidden' name='startstory' value='startstory'>
<br>
<input type="submit" value="Submit">
</form>
</blockquote>
</td></tr></table>

</td></tr></table>

<?php include("footer.inc"); ?>

</body>
</html>

