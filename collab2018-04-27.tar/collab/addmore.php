<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];
$addmore = $_POST["addmore"];
$startstory = $_POST["startstory"];
$edit = $_POST["edit"];
$posttext = $_POST["posttext"];
$posttitle = $_POST["posttitle"];

echo "<html>";
echo "<head>";
echo "<title>$title - Add To A Story</title>";
include ("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");
?>

<table><tr><td valign=top>
<?php include("posts.inc"); ?>
</td>
<td valign=top>

<?php
include("stories.inc");
echo "<a name='addmore'></a><p><blockquote><p>";
if($edit == "edittitle" || $edit == "editpost"){
?>

  <h4>Edit Post</h4>
  <form action="index.php" method="post">

<?php
  if($edit == "edittitle"){
?>

    Title:<br>
    <input type="text" name="posttitle" size='60' autofocus value="<?=$posttitle;?>">
    <p>
    Enter up to 1000 characters:<br>
    <textarea maxlength=<?=$maxchars ?> rows='20' cols='60' name='content'><?=$posttext;?></textarea>
    <input type='hidden' name='edittitle' value='edittitle'>

<?php
  }else{
?>

    <p>
    Enter up to 1000 characters:<br>
    <textarea autofocus maxlength=<?=$maxchars ?> rows='20' cols='60' name='content'><?=$posttext;?></textarea>
    <input type='hidden' name='editpost' value='editpost'>

  <?php
  }

  echo "<input type='hidden' name='fname' value='$fname'>";
  ?>

  <br>
  <input type="submit" value="Submit">
  </form>

<?php
}else{
?>

  <form action="index.php" method="post">
  <p>
  Enter up to 1000 characters:<br>

  <textarea autofocus maxlength=<?=$maxchars ?> rows='20' cols='60' name='content'></textarea>
  <input type='hidden' name='addmore' value='addmore'>

  <?php
  echo "<input type='hidden' name='fname' value='$fname'>";
  ?>

  <blockquote>
  <input type="submit" value="Submit">
  </form>

<?php
}
?>

</td></tr></table>

<?php
include("footer.inc");
?>

</body>
</html>
