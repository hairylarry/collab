<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

$message = "";
$profile = $_POST["profile"];
$profilename = $_POST["profilename"];
$changeusername = $_POST["changeusername"];
$changeemail = $_POST["changeemail"];
$viewall = $_POST["viewall"];

//change username
if($changeusername == "changeusername"){
  $un = $_POST["un"];
  $userfile = "usernames/".$username.".txt";
  if(file_exists($userfile)){
    $file = fopen($userfile, "r") or die("Unable to open user file! ".$userfile);
    $id = rtrim(fgets($file));
    $em = rtrim(fgets($file));
    $pw = rtrim(fgets($file));
    fclose($file);
  }else{
    echo "Unable to open user file! ".$userfile;
  }

  $file = fopen("usernames/".$un.".txt", "w") or die("Unable to open file! ".$fn);
  fwrite($file, $id."\n");
  fwrite($file, $em."\n");
  fwrite($file, $pw."\n");
  fwrite($file, $un."\n");
  fclose($file);

  $file = fopen("userids/".$id.".txt", "w") or die("Unable to open file! ".$fn);
  fwrite($file, $un."\n");
  fclose($file);

  $file = fopen("emails/".$em.".txt", "w") or die("Unable to open file! ".$fn);
  fwrite($file, $un."\n");
  fclose($file);

  $_SESSION["username"] = $un;
  $cookie_name = "username";
  $cookie_value = $un;
  setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

  unlink("usernames/".$username.".txt");
  header('Location: '.$wwwpath."/profile.php");
}

//change email
if($changeemail == "changeemail"){
  $email = $_POST["email"];
  $password = substr(crypt($_POST["password"], '$2a$07$MySaltIsPepperCayenneE$'),29);

  $userfile = "usernames/".$username.".txt";
  if(file_exists($userfile)){
    $file = fopen($userfile, "r") or die("Unable to open userfile! ".$userfile);
    $id = rtrim(fgets($file));
    $em = rtrim(fgets($file));
    $pw = rtrim(fgets($file));
    fclose($file);
  }else{
    echo "Unable to open user file! ".$userfile;
  }

  if($password == $pw){
    $file = fopen("usernames/".$username.".txt", "w") or die("Unable to open file! ".$fn);
    fwrite($file, $userid."\n");
    fwrite($file, $email."\n");
    fwrite($file, $password."\n");
    fwrite($file, $username."\n");
    fclose($file);

    $file = fopen("emails/".$email.".txt", "w") or die("Unable to open file! ".$fn);
    fwrite($file, $username."\n");
    fclose($file);
    unlink("emails/".$em.".txt");
  }else{
    $message .= "Wrong Password. Try Again.<p>";
  }
}

//post profile
if($profile == "profile"){
  $tagline = $_POST["tagline"];
  $content = $_POST["content"];
  $fname = $_POST["fname"];

  if(strlen($userid) == 0){
    $cookie_name = "username";
    if(!isset($_COOKIE[$cookie_name])) {
      echo "Oh oh, you're not logged in. Please copy your text, save it, and then <a href='login.php'>Log In</a>.";
      echo "<table width=600 border=1><tr><td>";
      echo "<blockquote><p>";
      echo $content;
      echo "</blockquote>";
      echo "</td></tr?</table>";
      break;
    } else {
      $username = $_COOKIE[$cookie_name];

      $userfile = "usernames/".$username.".txt";
      if(file_exists($userfile)){
        $file = fopen($userfile, "r") or die("Unable to open file! ".$userfile);
        $userid = rtrim(fgets($file));
        fclose($file);
      }else{
        echo "Unable to open user file! ".$userfile;
      }

      $_SESSION["userid"] = $userid;
      $_SESSION["username"] = $username;
    }
  }

  $file = fopen($fname,"w") or die("Unable to open file!");
  fwrite($file,":TAGLINE:".htmlspecialchars($tagline)."\n".htmlspecialchars($content));
  fclose($file);
}


echo "<html>";
echo "<head>";
echo "<title>$title - Profile</title>";
include("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");

echo "<table><tr><td valign=top>";
include("posts.inc");
echo "</td><td valign=top>";
include("profile.inc");
echo "</td></tr></table>";
include("footer.inc");
?>

</body>
</html>

