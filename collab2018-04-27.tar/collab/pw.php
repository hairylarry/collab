<?php
$pw = $_GET['pw'];
echo $pw."<br>";
echo substr(crypt($pw, '$2a$07$MySaltIsPepperCayenneE$'),29);
?>
