<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];
if($username <> "admin"){
  header("Location: ".$wwwpath."/index.php");
}

$adminmailout = $_POST["adminmailout"];
if($adminmailout == "adminmailout"){
  $subject = $_POST["subject"];
  $msg = $_POST["msg"];
  $headers = "From: ".$adminemail;

  //post email to sdf gopher and website
  $today =  date('Y-m-d');
  $fname = "/sdf/arpa/gm/h/hairylarry/gopher/collab_emails/adminemail".$today.".txt";
  $file = fopen($fname, "w") or die("Unable to open file! ".$userfile);
  fwrite($file, $subject." - ".$today."\n\n");
  fwrite($file, $msg."\n");
  fclose($file);

  //send emails
  $dir = "emails";
  $files = scandir($dir);
  $arrlength = count($files);
  for($x = 0; $x < $arrlength; $x++) {
    $filename = $files[$x];
    if(($filename<>".")&&($filename<>"..")&&($filename<>".htaccess")&&($filename<>"index.html") ){
      $email = substr($filename,0,-4);
      mail($email,$subject,$msg,$headers);
    }
  }
}

echo "<html>";
echo "<head>";
echo "<title>$title - Admin Email</title>";
include("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");

echo "<table><tr><td valign=top>";
include("posts.inc");
echo "</td><td valign=top>";
include("adminemail.inc");
echo "</td></tr></table>";
include("footer.inc");
?>

</body>
</html>

