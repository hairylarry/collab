<?php
include ("config.txt");
$msg = "Collab Weekly Digest - http://hairylarry.sdf.org/collab\n\nThese posts have been made to Collab in the last week.\nClick the link to read the story or add to it.\n\nYou can choose not to receive the weekly digest in your profile.\nOr reply to this email to contact the admin.\n\n ---\nNewest posts first.\n ---\n\n";

//include news.txt if it exists
$fname = "news.txt";
if (file_exists($fname)){
  $file = fopen($fname, "r") or die("Unable to open news file! ".$fname);
  while (!feof($file)) {
    $news .= fgets($file);
  }
  fclose($file);
  $msg .= "Collab News\n------------\n".$news."\n ---\n\n";
}

$dir = 'allposts';
$files = scandir($dir, 1);
$darray = array();
$i = 0;
while($i < 7){
  if(substr($files[$i],0,1) <> "."){
    array_push($darray,$files[$i]);
  }
  $i++;
}

$arrlength = count($darray);
for($x = 0; $x < $arrlength; $x++) {
  $filename = $darray[$x];
  $date = substr($filename,0,10);

  $array = explode("\n", file_get_contents("allposts/".$filename));
  $count = count($array);

  $i = $count-1;
  while($i > 0){
    $i = $i-1;
    $fname = $array[$i];
    $fid = substr($fname,0,6).".txt";

    if(file_exists($fname)){
      $file = fopen($fname, "r") or die("Unable to open story file! ".$fname);
      $line1 = fgets($file);
      $linet = $line1;

      if(substr($linet,0,7) == ":TITLE:"){
        $msg .= substr($linet,7)."\n";
      }else{
        //follow linked list up to title
        while(substr($linet,0,7) <> ":TITLE:"){
          $tname = rtrim(substr($linet,8));
          if(file_exists($tname)){
            $tfile = fopen($tname, "r") or die("Unable to open file in title loop!".$tname);
            $linet = fgets($tfile);
            fclose($tfile);
          }else{
            echo "Unable to open file in title loop!".$tname;
          }
        }
        $linet = str_replace("\n","",$linet);
        $msg .= substr($linet,7)."... continued\n\n";
      }

      while (!feof($file)) {
        $line = fgets($file);
        if(substr($line,0,7) <> ":CHILD:"){
          $msg .=  wordwrap(str_replace("&quot;",'"',$line));
        }
      }

      fclose($file);
    }else{
      echo "Unable to open story file! ".$fname;
    }

    $idfile = "userids/".$fid;
    if(file_exists($idfile)){
      $file = fopen($idfile, "r") or die("Unable to open id file! ".$idfile);
      $by = rtrim(fgets($file));
      fclose($file);
    }else{
      echo "Unable to open id file! ".$idfile;
    }

    $msg .= "\n\nPosted by $by - posted on ".substr($fname,7,10)." at ".substr($fname,18,5)." Central Time.\n";

    $msg .= "Read the story so far - $wwwpath/index.php?story=$fname\n\n ---\n\n";
  }
}
$subject = "Collab Weekly Digest";
$email = "hairylarry@gmail.com";
$headers = "From: ".$adminemail;

mail($email,$subject,$msg,$headers);
echo $msg;
?>

