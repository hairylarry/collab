<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

echo "<html>";
echo "<head>";
echo "<title>$title - Log In</title>";
include("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");

echo "<table><tr><td valign=top>";
include("posts.inc");
echo "</td><td valign=top>";
include("login.inc");
echo "</td></tr></table>";
include("footer.inc");
?>

</body>
</html>

