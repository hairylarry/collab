<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

$cc = $_GET['cc'];
$ccfile = "pending/".$cc.".txt";

if(file_exists($ccfile)){
  $file = fopen($ccfile,"r") or die("Unable to open file!".$ccfile);
  $username = rtrim(fgets($file));
  fclose($file);
}
?>

<script>
function validateForm(pw){
  if(pw.length>5){
    return true;
  }else{
    alert("Passwords must be at least 6 characters long.");
    return false;
  }
}
</script>

<?php
echo "<html>";
echo "<head>";
echo "<title>$title - Enter New Password</title>";
include("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");

echo "<table><tr><td valign=top>";
include("posts.inc");
echo "</td><td valign=top>";
include("lpw.inc");
echo "</td></tr></table>";
include("footer.inc");
?>

</body>
</html>

