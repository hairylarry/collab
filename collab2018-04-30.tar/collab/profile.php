<?php
session_start();
include("config.txt");
$userid = rtrim($_SESSION["userid"]);
$username = $_SESSION["username"];

$message = "";
$profile = $_POST["profile"];
$profilename = $_POST["profilename"];
$changeusername = $_POST["changeusername"];
$changeemail = $_POST["changeemail"];
$readinglistadd = $_POST["readinglistadd"];
$readinglistdel = $_POST["readinglistdel"];
$viewall = $_POST["viewall"];

//add profilename to reading list
if($readinglistadd == "readinglistadd"){
  $fname = "lists/".$username.".txt";
  $file = fopen($fname, "a") or die("Unable to open reading list file! ".$fname);
  fwrite($file, $profilename."\n");
  fclose($file);
}

//remove profilename to reading list
if($readinglistdel == "readinglistdel"){
  $fname = "lists/".$username.".txt";
  //read the reading list into rlstring
  $file = fopen($fname, "r") or die("Unable to open reading list file! ".$fname);
    while (!feof($file)) {
    $line = rtrim(fgets($file));
    if(($line <> $profilename) && ($line <> "")){
      $rlstring .= $line."\n";
    }
  }
  fclose($file);

  //write the reading list
  $file = fopen($fname, "w") or die("Unable to open reading list file! ".$fname);
  fwrite($file,$rlstring);
  fclose($file);
}

//change username
if($changeusername == "changeusername"){
  $un = $_POST["un"];
  $userfile = "usernames/".$username.".txt";
  if(file_exists($userfile)){
    $file = fopen($userfile, "r") or die("Unable to open user file! ".$userfile);
    $id = rtrim(fgets($file));
    $em = rtrim(fgets($file));
    $pw = rtrim(fgets($file));
    fclose($file);
  }else{
    echo "Unable to open user file! ".$userfile;
  }

  $file = fopen("usernames/".$un.".txt", "w") or die("Unable to open file! ".$fn);
  fwrite($file, $id."\n");
  fwrite($file, $em."\n");
  fwrite($file, $pw."\n");
  fwrite($file, $un."\n");
  fclose($file);

  $file = fopen("userids/".$id.".txt", "w") or die("Unable to open file! ".$fn);
  fwrite($file, $un."\n");
  fclose($file);

  $file = fopen("emails/".$em.".txt", "w") or die("Unable to open file! ".$fn);
  fwrite($file, $un."\n");
  fclose($file);

  $_SESSION["username"] = $un;
  $cookie_name = "username";
  $cookie_value = $un;
  setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

  unlink("usernames/".$username.".txt");
  header('Location: '.$wwwpath."/profile.php");
}

//change email
if($changeemail == "changeemail"){
  $email = $_POST["email"];
  $password = substr(crypt($_POST["password"], '$2a$07$MySaltIsPepperCayenneE$'),29);

  $userfile = "usernames/".$username.".txt";
  if(file_exists($userfile)){
    $file = fopen($userfile, "r") or die("Unable to open userfile! ".$userfile);
    $id = rtrim(fgets($file));
    $em = rtrim(fgets($file));
    $pw = rtrim(fgets($file));
    fclose($file);
  }else{
    echo "Unable to open user file! ".$userfile;
  }

  if($password == $pw){
    $file = fopen("usernames/".$username.".txt", "w") or die("Unable to open file! ".$fn);
    fwrite($file, $userid."\n");
    fwrite($file, $email."\n");
    fwrite($file, $password."\n");
    fwrite($file, $username."\n");
    fclose($file);

    $file = fopen("emails/".$email.".txt", "w") or die("Unable to open file! ".$fn);
    fwrite($file, $username."\n");
    fclose($file);
    unlink("emails/".$em.".txt");
  }else{
    $message .= "Wrong Password. Try Again.<p>";
  }
}

//post profile
if($profile == "profile"){
  $tagline = $_POST["tagline"];
  $content = $_POST["content"];
  $fname = $_POST["fname"];

  //notification flags
  $weeklydigest = $_POST["weeklydigest"];
  $started = $_POST["started"];
  $contributed = $_POST["contributed"];
  $readerstarted = "0";
  $readercontributed = "0";

  //set notification flags variable 5 binary digits in order listed above
  $notificationsflags = "";
  if($weeklydigest == "on"){$notificationflags .= "1";}else{$notificationflags .= "0";}
  if($started == "on"){$notificationflags .= "1";}else{$notificationflags .= "0";}
  if($contributed == "on"){$notificationflags .= "1";}else{$notificationflags .= "0";}
  if($readerstarted == "on"){$notificationflags .= "1";}else{$notificationflags .= "0";}
  if($readercontributed == "on"){$notificationflags .= "1";}else{$notificationflags .= "0";}

  if(strlen($userid) == 0){
    $cookie_name = "username";
    if(!isset($_COOKIE[$cookie_name])) {
      echo "Oh oh, you're not logged in. Please copy your text, save it, and then <a href='login.php'>Log In</a>.";
      echo "<table width=600 border=1><tr><td>";
      echo "<blockquote><p>";
      echo $content;
      echo "</blockquote>";
      echo "</td></tr?</table>";
      break;
    } else {
      $username = $_COOKIE[$cookie_name];

      $userfile = "usernames/".$username.".txt";
      if(file_exists($userfile)){
        $file = fopen($userfile, "r") or die("Unable to open file! ".$userfile);
        $userid = rtrim(fgets($file));
        fclose($file);
      }else{
        echo "Unable to open user file! ".$userfile;
      }

      $_SESSION["userid"] = $userid;
      $_SESSION["username"] = $username;
    }
  }

  $userfile = "usernames/".$username.".txt";
  if(file_exists($userfile)){
    $file = fopen($userfile, "r") or die("Unable to open file! ".$userfile);
    //skip userid, username, notification flags
    fgets($file);
    $useremail = rtrim(fgets($file));
    $userpassword = rtrim(fgets($file));
    fclose($file);
  }else{
    echo "Unable to open user file! ".$userfile;
  }

  $file = fopen($userfile, "w") or die("Unable to open file! ".$userfile);
  fwrite($file, $userid."\n");
  fwrite($file, $useremail."\n");
  fwrite($file, $userpassword."\n");
  fwrite($file, $username."\n");
  fwrite($file, $notificationflags."\n");
  fclose($file);

  //for form set notifications to checked if on
  if($weeklydigest == "on"){$weeklydigest = "checked";}else{$weeklydigest = "";}
  if($started == "on"){$started = "checked";}else{$started = "";}
  if($contributed == "on"){$contributed = "checked";}else{$contributed = "";}
  if($readerstarted == "on"){$readerstarted = "checked";}else{$notificationflags = "";}
  if($readercontributed == "on"){$readercontributed = "checked";}else{$readercontributed = "";}

  $file = fopen($fname,"w") or die("Unable to open file!");
  fwrite($file,":TAGLINE:".htmlspecialchars($tagline)."\n".htmlspecialchars($content));
  fclose($file);
}else{
  //read notification flags from user file
  $userfile = "usernames/".$username.".txt";
  if(file_exists($userfile)){
    $file = fopen($userfile, "r") or die("Unable to open file! ".$userfile);
    fgets($file);
    fgets($file);
    fgets($file);
    fgets($file);
    $notificationflags = rtrim(fgets($file));
    fclose($file);

    if(substr($notificationflags,0,1) == "1"){$weeklydigest = "checked";}else{$weeklydigest = "";}
    if(substr($notificationflags,1,1) == "1"){$started = "checked";}else{$started = "";}
    if(substr($notificationflags,2,1) == "1"){$contributed = "checked";}else{$contributed = "";}
    if(substr($notificationflags,3,1) == "1"){$readerstarted = "checked";}else{$notificationflags = "";}
    if(substr($notificationflags,4,1) == "1"){$readercontributed = "checked";}else{$readercontributed = "";}

  }else{
    echo "Unable to open user file! ".$userfile;
  }
}

echo "<html>";
echo "<head>";
echo "<title>$title - Profile</title>";
include("collab.css");
echo "</head>";
echo "<body>";
include("header.inc");

echo "<table><tr><td valign=top>";
include("posts.inc");
echo "</td><td valign=top>";
include("profile.inc");
echo "</td></tr></table>";
include("footer.inc");
?>

</body>
</html>

